const input = document.getElementById('inputBox');
const buttons = document.querySelectorAll('button');

let currentInput = "";

buttons.forEach((button) => {
    button.addEventListener('click', (event) => {
        const buttonValue = event.target.innerHTML;

        if (buttonValue === '=') {
            try { 
                currentInput = currentInput.trim() ? eval(currentInput) : "";
                inputBox.value = currentInput;
            } catch (error) {
                inputBox.value = "Error";
                currentInput = "";
            }
        } else if (buttonValue === 'C') {
            currentInput = "";
            inputBox.value = currentInput;
        } else if (buttonValue === 'DEL') {
            currentInput = currentInput.slice(0, -1);
            inputBox.value = currentInput;
        } else {
            currentInput += buttonValue;
            inputBox.value = currentInput;
        }
    });
});

// https://www.linkedin.com/in/sunil-patidar-a3223a11b/